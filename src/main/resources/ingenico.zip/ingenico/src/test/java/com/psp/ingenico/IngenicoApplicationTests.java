package com.psp.ingenico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngenicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
