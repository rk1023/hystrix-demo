package com.psp.paypal.controllers;

import java.time.LocalDateTime;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psp.paypal.dtos.PaymentResponseDTO;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PaymentController {
	@GetMapping("paypal/payment")
	public ResponseEntity<PaymentResponseDTO> payment() {
		log.info("/paypal/payment Entry time: {}", LocalDateTime.now());

		
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		return ResponseEntity
				.ok(PaymentResponseDTO.builder().amount("100").status("SUCCESS").message("payPal Payment").build());
	}
}
