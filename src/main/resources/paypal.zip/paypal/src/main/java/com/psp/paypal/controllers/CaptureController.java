package com.psp.paypal.controllers;

import java.time.LocalDateTime;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psp.paypal.dtos.PaymentResponseDTO;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CaptureController {

	@GetMapping("/paypal/capture")
	public ResponseEntity<PaymentResponseDTO> capture(long amount) {
		log.info("/CaptureController/capture Entry time: {}", LocalDateTime.now());
		log.info("/paypal/capture time: {}", LocalDateTime.now());
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		return ResponseEntity.ok(PaymentResponseDTO.builder().amount(String.valueOf(amount)).status("SUCCESS")
				.message("PayPal Capture").build());
	}
}
