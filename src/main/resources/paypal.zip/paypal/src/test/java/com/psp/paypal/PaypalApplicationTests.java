package com.psp.paypal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalApplicationTests {

	@Test
	void contextLoads() {
	}

}
